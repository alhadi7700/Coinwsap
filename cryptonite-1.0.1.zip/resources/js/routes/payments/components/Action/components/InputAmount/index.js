export * from "./inputAmount";
export {default} from "./inputAmount";

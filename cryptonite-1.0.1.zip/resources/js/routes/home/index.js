export * from "./home";
export {default} from "./home";

if (module.hot) {
    module.hot.accept();
}

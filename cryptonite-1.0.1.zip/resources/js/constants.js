export const DISPLAY_DATE_FORMAT = 'MMMM Do YYYY, h:mm a';

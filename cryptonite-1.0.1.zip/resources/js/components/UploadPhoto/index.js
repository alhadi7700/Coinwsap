export {default} from "./uploadPhoto";
export * from "./uploadPhoto";

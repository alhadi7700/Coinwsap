export * from "./bankLogo";
export {default} from "./bankLogo";

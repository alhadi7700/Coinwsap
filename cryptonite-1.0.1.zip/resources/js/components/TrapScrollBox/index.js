export * from "./trapScrollBox";
export {default} from "./trapScrollBox";

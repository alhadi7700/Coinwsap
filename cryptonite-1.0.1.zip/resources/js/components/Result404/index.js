export * from "./result404";
export {default} from "./result404";

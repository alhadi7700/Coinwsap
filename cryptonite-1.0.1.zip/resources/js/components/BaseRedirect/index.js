export {default} from "./baseRedirect";
export * from "./baseRedirect";

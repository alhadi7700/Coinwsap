export * from "./svgIconStyle";
export {default} from "./svgIconStyle";

export {default} from "./redirect";
export * from "./redirect";

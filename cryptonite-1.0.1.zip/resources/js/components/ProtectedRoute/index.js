export {default} from "./protectedRoute";
export * from "./protectedRoute";

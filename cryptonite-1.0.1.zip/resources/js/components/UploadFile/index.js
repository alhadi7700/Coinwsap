export * from "./uploadFile";
export {default} from "./uploadFile";

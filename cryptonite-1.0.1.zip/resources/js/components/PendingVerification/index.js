export * from "./pendingVerification";
export {default} from "./pendingVerification";

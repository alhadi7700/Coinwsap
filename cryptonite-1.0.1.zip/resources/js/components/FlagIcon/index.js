export * from "./flagIcon";
export {default} from "./flagIcon";

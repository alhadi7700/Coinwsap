export * from "./landing";
export {default} from "./landing";

if (module.hot) {
    module.hot.accept();
}

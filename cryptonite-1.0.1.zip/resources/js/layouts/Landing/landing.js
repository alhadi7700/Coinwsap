import React from "react";
import Routes from "routes/landing";

const Landing = () => {
    return <Routes />;
};

export default Landing;

import React from "react";
import Routes from "routes/auth";

const Auth = () => {
    return <Routes />;
};

export default Auth;
